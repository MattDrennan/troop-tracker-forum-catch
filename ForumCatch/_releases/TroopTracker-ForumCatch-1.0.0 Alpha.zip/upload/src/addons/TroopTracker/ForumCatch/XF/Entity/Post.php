<?php

/*namespace TroopTracker\ForumCatch\XF\Entity;

//use XF\Entity\Post;
use XF\Mvc\Entity\Structure;

class Post extends XFCP_Post
{
    public static function getStructure(Structure $structure)
    {
        $structure = parent::getStructure($structure);

        //$structure->table = 'xf_post';
        //$structure->shortName = 'XF:Post';
        //error_log( print_r($structure->columns, TRUE) );
        //error_log("test");
        return $structure;
    }

    public function _postSave()
    {
        $save = parent::_postSave();

        //$this->updateThreadRecord();

        //$thread = $this->Thread;

        //error_log( print_r($thread->Forum->_relations, TRUE) );
        //error_log("test");
    }
}*/